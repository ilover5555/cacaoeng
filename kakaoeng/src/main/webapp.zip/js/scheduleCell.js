function makeScheduleCell(row, width){
	var time = null;
	if(Number(row["hour"]) <= 12){
		time = 'AM';
	}
	else{
		time = 'PM';
		row["hour"] = Number(row["hour"])-12;
	}
	var hour = "%02d".format(Number(row["hour"]));
	var minute = "%02d".format(row["minute"]);
	var tag = '<div class="scheduleCell" style="width:'+ width +'px; height:100%;  float:left">'+
	'<div style="width:100%; height:30px; background-color: #BE0606;"><p class="center_text" style="text-align: center;  color: white; font-weight: bold">'+
	dayOfWeekMap[row["dayOfWeek"]]+
	'</p></div><div style="width:100%; height:77px; text-align: center;">'+
		'<p class="center_text" style="height:100%">&nbsp;'+ time+' ' + hour +':'+ minute +'</p>'+
	'</div><div style="width:100%; height:30px;"><p class="center_text" style="height:100%; background-color: #E1E1E1; margin: 0 auto">'+
	(Number(row["duration"])*25)+
	'분 수업</p></div></div></div>';
	return tag;
}

function makeSelectedTeacherDisplay(selectedResult){
	return "담당선생님:"+selectedResult["name"];
}

function makeClassRangeDisplay(realStartDate, realEndDate){
	var sDate = new Date(realStartDate);
	var eDate = new Date(realEndDate);
	var txt = "수업기간:"+ sDate.getFullYear() +"년"+ (sDate.getMonth()+1) +"월"+sDate.getDate()+"일("+dayOfWeekMap[sDate.getDay()]+")";
	txt += ' ~ ';
	txt += eDate.getFullYear() +"년"+ (eDate.getMonth()+1) +"월"+eDate.getDate()+"일("+dayOfWeekMap[eDate.getDay()]+")";
	return txt;
}

function showBox(){
	document.getElementById('light').style.display='block';
	document.getElementById('fade').style.display='block'
}

function hideBox(){
	document.getElementById('light').style.display='none';
	document.getElementById('fade').style.display='none'
}

$(document).keyup(function(e) {
    if (e.keyCode == 27) {
   	 hideBox();
   }
});

var scheduleCell= {"makeScheduleCell" : makeScheduleCell, "makeSelectedTeacherDisplay" : makeSelectedTeacherDisplay,
		"makeClassRangeDisplay" : makeClassRangeDisplay, "showBox" : showBox, "hideBox" : hideBox}; 